# RAT BENCH — Feature Map
> Living document. Update when features ship or queue changes.
> Legend: ✅ Done · 🔧 In progress · 📋 Queued · ❌ Blocked

---

## Dependency Stack (bottom = must exist first)

```
Supabase Auth
  └── profiles table
        └── tier system (gates.js)
              └── companies + company_members
                    └── machine_permissions
                    └── asset_permissions
                          └── vehicles / equipment / tools tables
              └── machines table (200+ cols)
                    └── services table
                    └── machine_bookings table
                    └── machine_permissions
              └── clients table
              └── inventory_items table
              └── wiki_entries + wiki_revisions tables
Stripe
  └── checkout / portal edge functions
        └── stripe-webhook edge function
              └── updates profiles.tier / companies.tier
```

---

## 1. Foundation

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| Supabase Auth (email/pass, anon guest) | ✅ | — | Free |
| Onboarding (username, account type) | ✅ | auth | Free |
| Password reset | ✅ | auth | Free |
| Guest upgrade modal | ✅ | auth | Free |
| Profiles table + RLS | ✅ | auth.users | Free |
| Tier system (`gates.js`) | ✅ | profiles.tier | All |
| Stripe Checkout | ✅ | Stripe, profiles | All |
| Stripe webhook → tier update | ✅ | Stripe, profiles/companies | All |
| Billing portal (manage/cancel) | ✅ | Stripe customer ID | All |
| Announcements (in-app banners) | ✅ | profiles.tier | All |

---

## 2. Machine Tracker (core)

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| machines table (200+ columns, RLS) | ✅ | profiles, companies | Free |
| Create / edit / delete machine | ✅ | machines table, transforms.js | Free |
| Machine form (all 200+ spec fields) | ✅ | machines, machineTypes constants | Free |
| List view + grid view | ✅ | machines, MachineTile, MachineCard | Free |
| Search, sort, filter by status | ✅ | machines | Free |
| Drag-to-reorder | ✅ | machines | Free |
| Machine limit enforcement (30 free) | ✅ | gates.js, machines count | Free |
| Configurable tile fields + colours | ✅ | machines, ui.js constants | Free |
| Configurable expand sections | ✅ | machines, ui.js constants | Free |
| PDF spec sheet export | ✅ | machines, jspdf | Free |
| Machine → client linking | ✅ | machines, clients table | Enthusiast+ |
| Machine → company tagging | ✅ | machines, companies | Team+ |
| Real-time sync (org machines) | ✅ | Supabase channel, company_id | Team+ |
| "Shared" badge on provisioned machines | ✅ | machine_permissions | Team+ |
| Wiki submission from machine | ✅ | wiki_entries, machines | Enthusiast+ |
| Rage rating (☠️ skulls) | ✅ | machines.rage | Free |
| Custom sections (user-defined spec blocks) | ✅ | machines.custom_sections (jsonb) | Free |
| Chipper / Stump Grinder spec fields | ✅ | machines, chipper_spec (jsonb) | Free |
| Tracked machine spec fields | ✅ | machines, tracked_* columns | Free |
| Outboard motor spec fields | ✅ | machines, ob_* columns | Free |
| Auto-calc: bore/stroke ratio | ✅ | machines.crank_stroke, bore | Free |
| Auto-calc: tyre size parser | ✅ | machines.tyre_front/rear | Free |
| Auto-calc: final drive + top speed | ✅ | machines.sprockets, gearing | Free |
| Auto-calc: blade tip speed | ✅ | machines.blade_length, wot_rpm | Free |
| Auto-calc: compression → octane | ✅ | machines.compression | Free |
| Auto-calc: hydraulic ram force/volume | ✅ | machines.hyd_rams (jsonb) | Free |
| Auto-calc: ground pressure (tracked) | ✅ | machines tracked fields | Free |
| Auto-calc: undercarriage wear % | ✅ | machines.track_pitch, link_count | Free |
| Auto-calc: electrical (lighting, wire drop) | ✅ | machines.lighting (jsonb) | Free |
| Auto-calc: battery energy / CCW | ✅ | machines.batteries (jsonb) | Free |
| Auto-calc: generator amps / max motor | ✅ | machines.gen_watts, gen_voltage | Free |
| Auto-calc: 2T mix oil quantity | ✅ | machines.mix_ratio, tank_capacity | Free |
| Auto-calc: pressure washer cleaning units | ✅ | machines.pump_psi, flow | Free |
| Auto-calc: net charge rate | ✅ | machines.charge_amps, lighting load | Free |
| Auto-calc: mean piston speed | ✅ | machines.crank_stroke, wot_rpm | Free |
| Auto-calc: rod ratio | ✅ | machines.conrod_length, stroke | Free |
| Auto-calc: suspension spring rate check | ✅ | machines.fork_type, spring_rate | Free |

---

## 3. Machine Provisioning (ACL)

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| machine_permissions table + RLS | ✅ | machines, company_members | Team+ |
| getMachines() returns provisioned machines | ✅ | machine_permissions | Team+ |
| Provisioning panel in CompanySettings | ✅ | machine_permissions, company_members | Team+ |
| Grant View / Grant Edit / Revoke per member | ✅ | machine_permissions | Team+ |
| Read-only machine card for View-only members | ✅ | machine_permissions, can_edit flag | Team+ |

---

## 4. Service Tracking

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| services table + RLS | ✅ | machines | Free |
| Log service entry (date, types, notes) | ✅ | services table | Free |
| Spark plug photo log | ✅ | services, photos (base64) | Free |
| Job photos per service | ✅ | services, photos | Free |
| Oil change interval (hrs or months) | ✅ | machines.oil_change_interval | Free |
| Major service interval (hrs or months) | ✅ | machines.major_service_interval | Free |
| Overdue / due-soon badge in tab bar | ✅ | getMachineServiceStatus() helper | Free |
| Progress bar (green → red) | ✅ | service intervals, last service date | Free |
| Service history timeline on machine card | ✅ | services table | Free |

---

## 5. Storage Policy

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| machine_bookings table + RLS | ✅ | machines, auth.users | Enthusiast+ |
| Global enable toggle (`profiles.storage_policy_enabled`) | ✅ | profiles | Enthusiast+ |
| Storage tiers (Bench/Small/Medium/Large/Extra Large/Custom) | ✅ | storageTiers.js DEFAULT_STORAGE_TIERS | Enthusiast+ |
| Configurable tier rates (freeDays/dailyRate/escalateDays/minFee) | ✅ | profiles.storage_tiers JSONB, getTiers(), StorageSettings inline edit | Enthusiast+ |
| Book In — create a booking with tier + received date | ✅ | machine_bookings, MachineCard | Enthusiast+ |
| Per-visit storage toggle (charge/pause billing) | ✅ | machine_bookings.storage_enabled | Enthusiast+ |
| Mark Collected — close booking, stop accrual | ✅ | collectMachine(), MachineCard | Enthusiast+ |
| Tile badge: free days remaining (green) | ✅ | getStorageStatus(), MachineCard | Enthusiast+ |
| Tile badge: accrued fees (orange) | ✅ | getStorageStatus(), MachineCard | Enthusiast+ |
| Tile badge: ⚠ FOR SALE escalation (red + glow) | ✅ | getStorageStatus(), MachineCard | Enthusiast+ |
| ServiceReminders: escalation + billing alerts | ✅ | getAllActiveBookings(), getStorageStatus() | Enthusiast+ |
| ServiceReminders: consumable stock alerts (LOW / OUT / OVER) | ✅ | getConsumables(), ServiceReminders.jsx | Free |
| Invoice: storage fees line item | ✅ | getActiveBooking(), exportClientInvoice() | Enthusiast+ |
| Storage Settings tab (toggle + editable tier table) | ✅ | StorageSettings.jsx, SettingsPage | Enthusiast+ |
| Booking history per machine | ✅ | getBookingHistory(), machine_bookings | Enthusiast+ |
| Custom daily rate override per visit | ✅ | machine_bookings.storage_fee_override | Enthusiast+ |
| Storage revenue in Revenue Dashboard | ✅ | getClosedBookings(), getClosedBookingFee(), RevenueDashboard | Enthusiast+ |
| Storage revenue card (realized, per period) | ✅ | filteredBookings, storageRev | Enthusiast+ |
| Storage revenue per-machine breakdown | ✅ | storageByMachineId, byMachine | Enthusiast+ |
| Storage included in Gross Profit total | ✅ | grossProfit = labour + parts + storage − cost | Enthusiast+ |

---

## 6. Job Board & Time Tracking

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| Job timer (start / stop / pause) | ✅ | machines.job_timer (jsonb) | Free |
| Multiple timers per machine | ✅ | machines.job_timer array | Free |
| Timer sync: lock when another member running | ✅ | job_timer.startedBy, Realtime | Team+ |
| Time log (save sessions with label + notes) | ✅ | machines.time_log (jsonb) | Free |
| Running timer badge in Jobs tab | ✅ | machines.job_timer status | Free |
| Invoice generation (labour + parts) | ✅ | time_log, inventory, company rates | Free |
| Parts markup on invoice | ✅ | inventory buy/sell price | Free |
| Tax calculation on invoice | ✅ | companies.tax_rate, tax_label | Team+ |
| Invoice number auto-increment | ✅ | invoices.js RPC + localStorage fallback | Free |
| HTML invoice export | ✅ | time_log, parts, company details | Free |
| Collapsed/expanded job card layout (matching asset tabs) | ✅ | JobBoard, JobCard | Free |
| Common jobs autocomplete | ✅ | COMMON_JOBS constant | Free |
| Barcode scanner (keyboard detection) | ✅ | inventory items | Free |
| Stock auto-deduct on part use (parts) | ✅ | adjustStock(), inventory | Free |
| Stock auto-deduct on consumable use | ✅ | adjustConsumableQty(), consumables | Free |
| Jobs picker: Parts tab + Consumables tab | ✅ | inventory + consumables, sourceType on entries | Free |
| Running cost total per job (parts + labour) | ✅ | machines.parts sellPrice, company.hourly_rate | Free |
| Cost Summary row in expanded job card | ✅ | partsTotal + labourTotal = grandTotal | Free |

---

## 7. Revenue Dashboard

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| Revenue totals (labour, parts & consumables, profit) | ✅ | time_log, inventory, consumables, company.hourly_rate | Enthusiast+ |
| Date filters (week / month / all / custom) | ✅ | time_log.completedAt, machine.parts[].usedAt | Enthusiast+ |
| Per-machine breakdown | ✅ | time_log, machines | Enthusiast+ |
| Tax deduction display | ✅ | companies.tax_rate | Team+ |
| Currency formatting | ✅ | companies.currency | Team+ |

---

## 8. Parts & Inventory

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| inventory_items table + RLS | ✅ | profiles | Free |
| Create / edit / delete parts | ✅ | inventory_items | Free |
| Buy price / sell price / stock qty | ✅ | inventory_items.payload (jsonb) | Free |
| Min par / max par levels with LOW/OVER badges | ✅ | inventory_items.payload minQuantity/maxQuantity | Free |
| 20 workshop-specific part categories (Tyres, Filters, Spark Plugs, Fasteners, Engine Components, etc.) | ✅ | partsTypes.js, StockItemTab typeConfig | Free |
| Category-specific spec fields per part type (gap/heat range for plugs, pitch/gauge for chains, ET/PCD for wheels, etc.) | ✅ | partsTypes.js PART_CATEGORY_SPECS | Free |
| Part category groups filter bar (Tyres & Wheels, Engine, Fuel & Induction, Ignition, Drive Train, etc.) | ✅ | partsTypes.js PART_CATEGORY_GROUPS | Free |
| QR code label generation + print | ✅ | inventory_items, qrcode library | Free |
| Barcode scanner input | ✅ | keyboard detection | Free |
| Stock adjustment (use / restock) | ✅ | inventory_items.payload | Free |
| Machine parts list (per-machine) | ✅ | machines.parts (jsonb) | Free |
| localStorage → Supabase migration | ✅ | inventory_items | Free |
| Photos per part (stored in payload JSONB) | ✅ | inventory_items.payload.photos | Free |
| Cover photo selection (☆ Cover) for parts | ✅ | PartsTab | Free |
| Shared UI (StockItemTab) with Consumables tab | ✅ | StockItemTab.jsx, tableType prop | Free |

---

## 9. Clients & Invoicing

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| clients table + RLS | ✅ | profiles, companies | Enthusiast+ |
| Create / edit / delete clients | ✅ | clients table | Enthusiast+ |
| Photos per client (clients.photos jsonb column) | ✅ | clients table, add_photos_to_clients.sql | Enthusiast+ |
| Cover photo selection (☆ Cover) for clients | ✅ | CustomersTab | Enthusiast+ |
| Link machines to clients | ✅ | machines.client_id | Enthusiast+ |
| Per-client invoice (all linked machines) | ✅ | time_log, parts, clients | Enthusiast+ |
| HTML invoice export with company header | ✅ | clients, companies, time_log | Enthusiast+ |
| localStorage → Supabase migration | ✅ | clients table | — |

---

## 10. Asset Tracking (Vehicles / Equipment / Tools)

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| asset_permissions table + RLS | ✅ | auth.users, company_members | Team+ |
| **vehicles** table + RLS | ✅ | asset_permissions | Free |
| Vehicles tab: CRUD + service log + photos | ✅ | vehicles table | Free (3 limit) |
| Vehicle service log: full ServiceModal (types, datetime, plug photo, job photos, edit) | ✅ | ServiceModal, VehiclesTab | Free |
| Sort modal + list/grid view toggle (Vehicles) | ✅ | VehiclesTab, AssetTile | Free |
| **equipment** table + RLS | ✅ | asset_permissions | Free |
| Equipment tab: CRUD + service log + photos | ✅ | equipment table | Free (3 limit) |
| Sort modal + list/grid view toggle (Equipment) | ✅ | EquipmentTab, AssetTile | Free |
| **tools** table + RLS | ✅ | asset_permissions | Free |
| Tools tab: CRUD + warranty + loan tracking | ✅ | tools table | Free (3 limit) |
| Sort modal + list/grid view toggle (Tools) | ✅ | ToolsTab, AssetTile | Free |
| localStorage → Supabase migration (tools) | ✅ | tools table | — |
| Free-tier item limit (3 per type) | ✅ | gates.js assetLimit() | Free |
| Upgrade banner at limit | ✅ | atAssetLimit() | Free |
| Org provisioning (grant/revoke per member) | ✅ | asset_permissions, CompanySettings | Team+ |
| **asset_assignments** table + RLS (replaces vehicle_assignments for cross-type) | ✅ | asset_assignments_migration.sql | Free |
| All-to-all cross-assignment (vehicle/tool/equipment/consumable/part) | ✅ | asset_assignments, LoadoutSection | Free |
| Forward loadout panel (Assigned Items + picker) | ✅ | LoadoutSection, VehiclesTab, ToolsTab, EquipmentTab, ConsumablesTab | Free |
| Parts (inventory items) assignable via Loadout picker | ✅ | getInventoryItems() wrapper, LoadoutSection | Free |
| Reverse lookup panel (Assigned To) | ✅ | getAssignedIn(), LoadoutSection | Free |
| Unassign items from loadout | ✅ | unassignAsset(), LoadoutSection | Free |
| **consumables** table + RLS | ✅ | asset_permissions | Free |
| Consumables tab: CRUD + qty tracking + stock alerts | ✅ | consumables table | Free (10 limit) |
| Sort modal + list/grid view toggle (Consumables) | ✅ | ConsumablesTab, AssetTile | Free |
| 80+ common presets (oils, fuels, coolants, welding, abrasives…) | ✅ | consumableTypes.js COMMON_CONSUMABLES | Free |
| Category-specific spec fields (viscosity, octane, DOT, ISO grade…) | ✅ | consumableTypes.js CATEGORY_SPECS | Free |
| ± stock adjustment inline on card | ✅ | adjustConsumableQty(), StockItemTab | Free |
| Cover photo selection (☆ Cover sets card thumbnail) | ✅ | VehiclesTab, ToolsTab, EquipmentTab, ConsumablesTab, MachineCard | Free |
| Photos for consumables (add via form, thumbnail in card, cover selection) | ✅ | ConsumablesTab, consumables table photos column | Free |
| Machine card collapsed header shows cover photo thumbnail | ✅ | MachineCard | Free |
| Low-stock / out-of-stock badge + overstock badge | ✅ | qtyLabel(), min_quantity / max_quantity thresholds | Free |
| Configurable min par (reorder point) and max par (ceiling) | ✅ | consumables.min_quantity, consumables.max_quantity | Free |
| Buy price / sell price / supplier / part number / location | ✅ | consumables.buy_price, sell_price, supplier, part_number, location | Free |
| Shared UI (StockItemTab) with Parts tab | ✅ | StockItemTab.jsx, tableType="consumable" | Free |
| Org provisioning for consumables | ✅ | asset_permissions, CompanySettings | Team+ |
| Assign org member to vehicle (VehicleMemberSection) | ✅ | getCompanyMembers(), assignAsset child_type='member', company prop | Team+ |

---

## 11. Team & Organisation

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| companies table + RLS | ✅ | profiles | Team+ |
| Create / edit company | ✅ | companies | Team+ |
| Invite code join flow | ✅ | companies.invite_code, RPC | Team+ |
| company_members table | ✅ | companies, profiles | Team+ |
| Roles: owner / admin / technician / viewer | ✅ | company_members.role | Team+ |
| Edit member roles | ✅ | updateMemberRole() RPC | Team+ |
| Remove member | ✅ | removeMember() RPC | Team+ |
| Regenerate invite code | ✅ | regenerateInviteCode() RPC | Team+ |
| Company logo upload | ✅ | companies.logo (base64) | Team+ |
| Hourly rate / tax rate / currency config | ✅ | companies fields | Team+ |
| Machine provisioning panel (CompanySettings) | ✅ | machine_permissions | Team+ |
| Asset provisioning panel (vehicles/equip/tools) | ✅ | asset_permissions, CompanySettings | Team+ |

---

## 12. Wiki

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| wiki_entries table | ✅ | — | Free |
| wiki_revisions table | ✅ | wiki_entries | Enthusiast+ |
| Browse + search wiki | ✅ | wiki_entries | Free |
| View count tracking | ✅ | wiki_entries.view_count | Free |
| Create / edit wiki entry | ✅ | wiki_entries | Enthusiast+ |
| Field-level editing with edit summary | ✅ | wiki_revisions | Enthusiast+ |
| Full revision history | ✅ | wiki_revisions | Enthusiast+ |
| Submit machine specs to wiki | ✅ | machines → wiki_entries | Enthusiast+ |
| Author attribution | ✅ | wiki_revisions.author_id | Enthusiast+ |
| Admin delete any wiki entry | ✅ | VITE_ADMIN_EMAIL env var check in WikiEntryPage, deleteWikiEntry() | Admin only |

---

## 12. Navigation & UX

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| 🔨 Workshop parent tab (nested sub-tab bar) | ✅ | App.jsx, WORKSHOP_TABS constant | Free |
| Workshop sub-tabs: Parts, Clients, Tools, Vehicles, Equipment, Consumables, Revenue | ✅ | WORKSHOP_TABS, App.jsx content panels | Free / Ent+ |
| Free-tier Workshop banner (5-item limit nudge + upgrade link) | ✅ | effectiveTier(), Workshop tab | Free |
| Revenue sub-tab gated behind Enthusiast+ | ✅ | WORKSHOP_TABS enthusiastOnly flag | Enthusiast+ |
| Per-user Workshop tab visibility preferences | ✅ | profiles.tab_order.workshop_visible (Supabase), TabOrderSettings.jsx checkboxes | Free |
| Per-user Workshop default sub-tab | ✅ | First visible tab in ordered workshop list (implicit, no separate setting) | Free |
| Workshop visibility + order UI under Settings → ⇅ Tabs | ✅ | TabOrderSettings.jsx WorkshopReorderList (checkboxes + ↑/↓ + DEFAULT badge) | Free |
| Users tab moved into Settings (team/business only) | ✅ | SettingsPage, UsersTab | Team+ |
| localStorage migration (old flat tab IDs → workshop sub-tabs) | ✅ | App.jsx init state | Free |
| Settings tab bar horizontally scrollable on mobile | ✅ | SettingsPage.jsx overflowX:auto | Free |
| Per-account tab reordering (main nav, workshop, settings) | ✅ | profiles.tab_order JSONB, applyTabOrder(), TabOrderSettings.jsx | Free |
| Tab order UI under Settings → ⇅ Tabs (↑/↓ reorder + reset) | ✅ | TabOrderSettings.jsx | Free |
| Tab order persists across sessions and devices | ✅ | Supabase profiles.tab_order, loaded on profile fetch | Free |

---


## 13. Towing Allocations (Admin Only)

| Feature | Status | Depends on | Tier |
|---------|--------|-----------|------|
| Towing section — admin-gated (VITE_ADMIN_EMAIL) | ✅ | session.user.email check, App.jsx | Admin only |
| **6-tab layout: Allocations · Pager · Alerts · Traffic · Analytics · Fleet** | ✅ | TowingSection.jsx | Admin only |
| Tow Allocations tab — polls VicRoads disruptions API every 60s | ✅ | TowAllocationsTab.jsx, fetch + setInterval, VITE_VICROADS_KEY | Admin only |
| Traffic signal indicator on allocation cards — logs non-TowAllocation VicRoads events to traffic_event_log; shows 🚦 +Xm badge (time gap between traffic first-seen and tow dispatch) and full Traffic Signal section in expanded view | ✅ | TowAllocationsTab.jsx, towing.js logTrafficEvents/getTrafficSignals, supabase/add_traffic_event_log.sql | Admin only |
| Filter feed to TowAllocation source only | ✅ | properties.source.sourceName === 'TowAllocation' | Admin only |
| Allocation cards (road, suburb, eventId, status badge, lanes, timestamps) | ✅ | TowAllocationsTab.jsx AllocationCard | Admin only |
| Active / Inactive grouping with counts | ✅ | TowAllocationsTab.jsx | Admin only |
| Live countdown + manual refresh button | ✅ | TowAllocationsTab.jsx | Admin only |
| Sort picker (Most Recent, Oldest, Road Name, Suburb, Lanes, Event ID) | ✅ | TowAllocationsTab.jsx SORT_OPTIONS | Admin only |
| Time-in duration badge on each card (elapsed since first seen) | ✅ | TowAllocationsTab.jsx timeIn() | Admin only |
| Active / Cleared status badges — feed presence is source of truth | ✅ | TowAllocationsTab.jsx StatusBadge, liveIds | Admin only |
| GPS proximity pulse — cards within 10km of user glow with slow pulsing red outline; uses watchPosition, cleans up on unmount; active allocations only | ✅ | TowAllocationsTab.jsx haversineKm(), pulse-nearby keyframe, userPos state | Admin only |
| Assign Truck stub (Phase 2 placeholder) | ✅ | TowAllocationsTab.jsx — disabled button, ready for wiring | Admin only |
| Fleet tab — depots CRUD | ✅ | depots table + RLS, FleetTab.jsx | Admin only |
| Fleet tab — tow trucks CRUD grouped by depot | ✅ | tow_trucks table + RLS, FleetTab.jsx | Admin only |
| Truck status badges (available / on job / unavailable) | ✅ | FleetTab.jsx statusColor() | Admin only |
| tow_trucks.assigned_event_id column (Phase 2 ready) | ✅ | create_towing_tables.sql | Admin only |
| Truck driver details — DA Number, Driver Name fields on truck form | ✅ | FleetTab.jsx TruckForm, add_truck_schedule.sql | Admin only |
| Truck availability roster — interactive 5-week calendar (tap to cycle off/day/night/both) | ✅ | RosterCalendar.jsx RosterCalendar, tow_trucks.schedule JSONB date-keyed | Admin only |
| Roster quick-fill buttons — Mon–Fri day/night, every weekend, alternating weekend A/B | ✅ | RosterCalendar.jsx QUICK fills, ISO week alternation | Admin only |
| 14-day colour strip on truck row — orange=day, blue=night, split=both (MiniRoster) | ✅ | RosterCalendar.jsx MiniRoster, TruckRow | Admin only |
| Relief driver roster calendar — same RosterCalendar in AvailabilityModal relief section | ✅ | RosterCalendar.jsx, AvailabilityModal | Admin only |
| Availability override modal (📅 button) — mark truck temporarily unavailable with reason + return date | ✅ | FleetTab.jsx AvailabilityModal, add_truck_override.sql | Admin only |
| Relief driver assignment — alternate driver name, DA number, and day/night schedule per truck | ✅ | FleetTab.jsx AvailabilityModal relief section, tow_trucks.relief_* columns | Admin only |
| TruckRow override states — red/AWAY badge (unavailable, no cover), yellow/RELIEF badge (relief driver active) | ✅ | FleetTab.jsx TruckRow, override_active + relief_driver_name | Admin only |
| Clear Override button — one-click restore to normal driver/schedule/available status | ✅ | FleetTab.jsx AvailabilityModal handleClear | Admin only |
| tow_allocation_log table — persists every polled allocation by event_id | ✅ | add_tow_allocation_log.sql, logAllocations() | Admin only |
| 24hr history loaded from log on mount (before first live poll) | ✅ | getRecentAllocations(24), TowAllocationsTab.jsx | Admin only |
| Live + log merged by eventId — live wins on conflict | ✅ | mergeFeatures(), TowAllocationsTab.jsx | Admin only |
| LOG purge cron job — deletes entries older than 365 days (daily at 03:00 UTC) | ✅ | tow_log_cleanup_cron.sql, pg_cron | Admin only |
| LOG badge on historical-only cards (not in current live feed) | ✅ | fromLog prop, AllocationCard | Admin only |
| PDF export with selectable period (15 min → 31 days) — A4 report with summary boxes + table | ✅ | TowAllocationsTab.jsx handleExport(), jsPDF, getRecentAllocations() | Admin only |
| Incident type badge on card header (eventSubType: "Stationary vehicle" etc.) | ✅ | TowAllocationsTab.jsx AllocationCard, p.eventSubType | Admin only |
| Cross street shown on card (startIntersectionRoadName @ suburb) | ✅ | TowAllocationsTab.jsx AllocationCard, p.reference.startIntersectionRoadName | Admin only |
| Melway grid reference on card (e.g. Mel 2E B1) | ✅ | TowAllocationsTab.jsx AllocationCard, p.melway | Admin only |
| Google Maps link in expanded card view (from geometry coordinates) | ✅ | TowAllocationsTab.jsx AllocationCard, feature.geometry.coordinates | Admin only |
| Expanded detail grid: Event Type, Incident Type, Cross Street, Melway, Coordinates | ✅ | TowAllocationsTab.jsx AllocationCard expanded section | Admin only |
| Analytics tab — KPI row (total jobs, avg/day, peak hour, top suburb, avg duration) | ✅ | TowAnalyticsTab.jsx, getAllocationsForAnalytics() | Admin only |
| Analytics — incident map: orange hotspot clusters (historical), green active dots (live VicRoads), grey cleared dots (last 1hr from log) | ✅ | TowAnalyticsTab.jsx HeatMap, leaflet | Admin only |
| Analytics — map legend overlay (bottom-left) click-to-toggle per layer with counts; viewport auto-fits visible layers | ✅ | TowAnalyticsTab.jsx legend overlay | Admin only |
| Analytics — click active/cleared map dot → AllocationCard pops up at corner of dot within map (no screen dim); smart left/right/top/bottom anchoring; ✕ or background click to dismiss; popup tracks dot during pan/zoom via latLngToContainerPoint on map 'move' event | ✅ | TowAnalyticsTab.jsx inline popup, AllocationCard exported from TowAllocationsTab | Admin only |
| Pager tab (📟) — merges Supabase pager_messages (SA GRN) + VicEmergency CFA incidents in parallel via Promise.allSettled; last 2h, newest-first, polls every 60s | ✅ | PagerTab.jsx, pager_messages table, /.netlify/functions/vic-emergency | Admin only |
| Pager — VicEmergency incidents filtered to feedType=incident or has category1; time-windowed to last 2h | ✅ | PagerTab.jsx normaliseEmergency(), fetchAll() | Admin only |
| Pager — filter pills (All / 🔥 VIC / CFS / MFS / SES / SAAS / MEDSTAR) colour-coded by agency | ✅ | PagerTab.jsx AGENCY_COLOR, FILTERS | Admin only |
| Pager — cards: 📟 icon for SA GRN messages, fire/rescue icons for VIC incidents; agency badge, incident type, address, raw message, time-ago | ✅ | PagerTab.jsx PagerCard, incidentIcon() | Admin only |
| Pager — expandable card body: raw pager message text + Google Maps link (VIC incidents with geometry) | ✅ | PagerTab.jsx PagerCard expanded | Admin only |
| Pager — VicEmergency data live immediately (no VPS needed); SA GRN messages populate once VPS pipeline is running | ✅ | PagerTab.jsx | Admin only |
| pager_messages table + RLS — service role insert (VPS), authenticated read (browser) | ✅ | supabase/add_pager_messages.sql | Admin only |
| VPS pager service — connects to sapaging.com Socket.IO server-side (no CORS), writes to pager_messages | 📋 | Needs VPS; direct browser connection blocked by CORS | Admin only |
| Waze tab (🚗) — dedicated Waze user-reported alerts feed; Melbourne metro bounding box; polls every 60s via /.netlify/functions/waze-alerts | ✅ | AlertsTab.jsx (renamed content), netlify/functions/waze-alerts.js | Admin only |
| Waze — filter pills (All / 💥 Accident / ⚠️ Hazard / 🚗 Jam / 🚧 Road Closed) with live counts | ✅ | AlertsTab.jsx FILTERS, TYPE_COLOR | Admin only |
| Waze — cards: type-coloured left border, confirm badge, street + suburb, time-ago; expandable with reliability score + Google Maps link | ✅ | AlertsTab.jsx WazeCard | Admin only |
| radio_transcripts table + RLS — service role insert (VPS), authenticated read (browser); reserved for future VPS transcription pipeline | ✅ | supabase/add_radio_transcripts.sql | Admin only |
| Traffic tab (🗺) — VicRoads unplanned disruptions + VicEmergency incidents merged, last 24h, sorted newest-first | ✅ | TrafficTab.jsx, VITE_VICROADS_KEY, EMERGENCY_URL, Promise.allSettled | Admin only |
| Traffic — both feeds non-fatal: VicRoads still shows if VicEmergency fails and vice versa | ✅ | TrafficTab.jsx Promise.allSettled, try/catch per source | Admin only |
| Traffic — filter pills (All / Accident / Breakdown / Flooding / Road Damage / Emergency / Other) with live counts | ✅ | TrafficTab.jsx FILTERS, toFilter() | Admin only |
| Traffic — expandable incident cards: status badge, type icon, suburb, time ago, Google Maps link | ✅ | TrafficTab.jsx IncidentCard, incidentIcon() | Admin only |
| Traffic — countdown timer + manual refresh; auto-refresh every 60 seconds | ✅ | TrafficTab.jsx setInterval, countdown state | Admin only |
| Analytics — jobs by hour of day chart (24-bar) | ✅ | TowAnalyticsTab.jsx HourChart | Admin only |
| Analytics — jobs by day of week chart | ✅ | TowAnalyticsTab.jsx DowChart | Admin only |
| Analytics — hot suburbs + hot roads ranked bar lists | ✅ | TowAnalyticsTab.jsx BarList | Admin only |
| Analytics — incident type + impact type breakdowns | ✅ | TowAnalyticsTab.jsx BarList | Admin only |
| Analytics — period selector (7d / 30d / 90d / 1yr) | ✅ | TowAnalyticsTab.jsx PERIODS, getAllocationsForAnalytics(days) | Admin only |

---

## 14. Queued Features

| Feature | Status | Blocked by / Notes |
|---------|--------|--------------------|
| Asset provisioning UI in CompanySettings | ✅ | Ships with Machines + Vehicles + Equipment + Tools sections |
| Assign driver/member to vehicle | ✅ | Shipped: VehicleMemberSection in VehiclesTab |
| Workshop tab visibility stored in profiles (cross-device sync) | ✅ | Shipped: profiles.tab_order.workshop_visible, syncs via Supabase |
| VPS radio transcription service — ffmpeg + silero-vad + faster-whisper large-v3 → Supabase radio_transcripts | 📋 | Needs Broadcastify Premium (or free stream URL); separate Python service, not in this repo |
| Photo migration → Supabase Storage | 📋 | Currently base64 in DB rows — expensive |
| Push notifications (service due) | 📋 | Needs FCM or similar |
| Smart Mode cascade calculations | 📋 | Needs multiple sections complete |
| Invoice / Quote PDF (separate from spec PDF) | 📋 | Currently HTML export only |
| General Terms of Service page | ✅ | TermsPage.jsx — linked from AuthScreen footer + signup consent |
| Privacy Policy page | ✅ | PrivacyPage.jsx — linked from AuthScreen footer + signup consent |
| API access (Business tier) | ❌ | Removed from billing copy — not being built |
| Firebase migration | 📋 | Long-term — after features stable |

---

## How to read this

- **"Depends on"** = the thing must exist and work for this feature to function. If you break the dependency, this feature breaks.
- **Tier** = minimum tier required. Free features work for everyone.
- Features in section 12 have no code yet. Everything else is live.
