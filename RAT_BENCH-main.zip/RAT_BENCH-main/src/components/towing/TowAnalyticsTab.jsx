import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import 'leaflet/dist/leaflet.css';
import { ACC, MUT, BRD, TXT, GRN, SURF } from '../../lib/styles';
import { getAllocationsForAnalytics, getRecentAllocations } from '../../lib/db/towing';
import { AllocationCard } from './TowAllocationsTab';

const ORANGE = '#e8870a';
const API_URL = 'https://api.opendata.transport.vic.gov.au/api/opendata/roads/disruptions/unplanned/v3';
const API_KEY = import.meta.env.VITE_VICROADS_KEY || 'bb7fc352-3ce6-44d2-9628-63fefb64278d';
const PERIODS = [
  { label: '7d',  days: 7   },
  { label: '30d', days: 30  },
  { label: '90d', days: 90  },
  { label: '1yr', days: 365 },
];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

// ── Helpers ───────────────────────────────────────────────────────────────────

function tally(arr, keyFn) {
  const map = {};
  arr.forEach(item => {
    const k = keyFn(item) || 'Unknown';
    map[k] = (map[k] || 0) + 1;
  });
  return Object.entries(map).sort((a, b) => b[1] - a[1]);
}

function fmtDuration(mins) {
  if (mins == null) return '—';
  if (mins < 60) return `${Math.round(mins)}m`;
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

// ── Sub-components ────────────────────────────────────────────────────────────

function KpiCard({ label, value, sub, color = TXT }) {
  return (
    <div style={{ background: SURF, border: '1px solid ' + BRD, borderTop: `2px solid ${color}`, borderRadius: 2, padding: '10px 12px', flex: 1, minWidth: 90 }}>
      <div style={{ fontSize: 7, color: MUT, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 700, color, fontFamily: "'IBM Plex Mono',monospace", lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 8, color: MUT, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function BarList({ data, color = ORANGE, maxBars = 10, labelWidth = 110 }) {
  const max = Math.max(...data.map(([, v]) => v), 1);
  if (!data.length) return <div style={{ fontSize: 9, color: MUT, padding: '12px 0' }}>No data yet</div>;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
      {data.slice(0, maxBars).map(([label, val]) => (
        <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: labelWidth, fontSize: 8, color: MUT, flexShrink: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'right' }} title={label}>{label}</div>
          <div style={{ flex: 1, background: '#1a1a1a', borderRadius: 1, height: 13, overflow: 'hidden', position: 'relative' }}>
            <div style={{ width: `${(val / max) * 100}%`, height: '100%', background: color, borderRadius: 1, transition: 'width 0.5s ease' }} />
          </div>
          <div style={{ width: 26, fontSize: 8, color: TXT, fontFamily: "'IBM Plex Mono',monospace", flexShrink: 0 }}>{val}</div>
        </div>
      ))}
    </div>
  );
}

function HourChart({ counts }) {
  const max = Math.max(...counts, 1);
  return (
    <div style={{ display: 'flex', gap: 2, alignItems: 'flex-end', height: 70, padding: '0 2px' }}>
      {counts.map((v, h) => (
        <div key={h} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <div
            title={`${String(h).padStart(2, '0')}:00 — ${v} job${v !== 1 ? 's' : ''}`}
            style={{ width: '100%', background: v > 0 ? ORANGE : '#1c1c1c', borderRadius: '1px 1px 0 0', height: `${Math.max((v / max) * 58, v > 0 ? 3 : 0)}px`, transition: 'height 0.5s ease', cursor: 'default' }}
          />
          {h % 6 === 0 && <span style={{ fontSize: 6, color: '#444', fontFamily: "'IBM Plex Mono',monospace", marginTop: 2 }}>{String(h).padStart(2, '0')}</span>}
        </div>
      ))}
    </div>
  );
}

function DowChart({ counts }) {
  const max = Math.max(...counts, 1);
  return (
    <div style={{ display: 'flex', gap: 4, alignItems: 'flex-end', height: 70 }}>
      {counts.map((v, d) => (
        <div key={d} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
          <div
            title={`${DAYS[d]} — ${v} job${v !== 1 ? 's' : ''}`}
            style={{ width: '100%', background: v > 0 ? ACC : '#1c1c1c', borderRadius: '1px 1px 0 0', height: `${Math.max((v / max) * 58, v > 0 ? 3 : 0)}px`, transition: 'height 0.5s ease', cursor: 'default' }}
          />
          <span style={{ fontSize: 7, color: MUT }}>{DAYS[d]}</span>
        </div>
      ))}
    </div>
  );
}

// ── Map ───────────────────────────────────────────────────────────────────────

// activePoints / clearedPoints: [{ pos: [lat, lng], feature }]
function HeatMap({ hotspots, activePoints, clearedPoints, showHotspots, showActive, showCleared, onFeatureClick, onMapReady }) {
  const containerRef = useRef(null);
  const mapRef       = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;

    import('leaflet').then(mod => {
      const L = mod.default || mod;

      if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }

      const map = L.map(containerRef.current, {
        center: [-37.814, 144.963],
        zoom: 11,
        zoomControl: true,
        attributionControl: false,
      });

      const tilePane = map.getPanes().tilePane;
      tilePane.style.filter = 'invert(100%) hue-rotate(180deg) brightness(90%) contrast(90%) saturate(60%)';

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        subdomains: 'abc',
        maxZoom: 19,
      }).addTo(map);

      L.control.attribution({ prefix: false })
        .addAttribution('© <a href="https://openstreetmap.org" style="color:#666">OpenStreetMap</a>')
        .addTo(map);

      const addClickable = (markers, feature, fromLog) => {
        markers.forEach(m => {
          m.on('click', (e) => {
            e.originalEvent.stopPropagation();
            onFeatureClick.current({ feature, fromLog, latlng: e.latlng });
          });
          m.addTo(map);
        });
      };

      if (showHotspots) {
        hotspots.forEach(([lat, lng]) => {
          L.circleMarker([lat, lng], { radius: 28, fillColor: ORANGE, fillOpacity: 0.07, stroke: false }).addTo(map);
          L.circleMarker([lat, lng], { radius: 10, fillColor: ORANGE, fillOpacity: 0.22, stroke: false }).addTo(map);
          L.circleMarker([lat, lng], { radius: 4,  fillColor: '#ffcc66', fillOpacity: 0.6,  stroke: false }).addTo(map);
        });
      }

      if (showActive) {
        activePoints.forEach(({ pos: [lat, lng], feature }) => {
          addClickable([
            L.circleMarker([lat, lng], { radius: 18, fillColor: GRN, fillOpacity: 0.12, stroke: false }),
            L.circleMarker([lat, lng], { radius: 7,  fillColor: GRN, fillOpacity: 0.45, stroke: false }),
            L.circleMarker([lat, lng], { radius: 3,  fillColor: '#aaffaa', fillOpacity: 0.9, stroke: false }),
          ], feature, false);
        });
      }

      if (showCleared) {
        clearedPoints.forEach(({ pos: [lat, lng], feature }) => {
          addClickable([
            L.circleMarker([lat, lng], { radius: 14, fillColor: '#555', fillOpacity: 0.18, stroke: false }),
            L.circleMarker([lat, lng], { radius: 5,  fillColor: '#888', fillOpacity: 0.55, stroke: false }),
            L.circleMarker([lat, lng], { radius: 2,  fillColor: '#bbb', fillOpacity: 0.8,  stroke: false }),
          ], feature, true);
        });
      }

      const allVisible = [
        ...(showHotspots ? hotspots                         : []),
        ...(showActive   ? activePoints.map(p => p.pos)    : []),
        ...(showCleared  ? clearedPoints.map(p => p.pos)   : []),
      ];
      if (allVisible.length > 0) {
        const lats = allVisible.map(p => p[0]);
        const lngs = allVisible.map(p => p[1]);
        map.fitBounds([
          [Math.min(...lats) - 0.04, Math.min(...lngs) - 0.06],
          [Math.max(...lats) + 0.04, Math.max(...lngs) + 0.06],
        ], { maxZoom: 13 });
      }

      mapRef.current = map;
      if (onMapReady) onMapReady(map);
    });

    return () => {
      if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }
      if (onMapReady) onMapReady(null);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hotspots, activePoints, clearedPoints, showHotspots, showActive, showCleared]);

  return (
    <div ref={containerRef} style={{ width: '100%', height: '100%', borderRadius: 2 }} />
  );
}

// ── Main tab ──────────────────────────────────────────────────────────────────

export default function TowAnalyticsTab() {
  const [days,            setDays]            = useState(30);
  const [rows,            setRows]            = useState([]);
  const [loading,         setLoading]         = useState(true);
  const [activeRaw,       setActiveRaw]       = useState([]);
  const [clearedRaw,      setClearedRaw]      = useState([]);
  const [showHotspots,    setShowHotspots]    = useState(true);
  const [showActive,      setShowActive]      = useState(true);
  const [showCleared,     setShowCleared]     = useState(true);
  const [selectedFeature, setSelectedFeature] = useState(null);
  const [popupPos,        setPopupPos]        = useState(null);
  const onFeatureClick  = useRef(null);
  const mapInstanceRef  = useRef(null);
  onFeatureClick.current = sel => setSelectedFeature(sel);

  const onMapReady = useCallback((map) => {
    mapInstanceRef.current = map;
  }, []);

  // Recalculate popup pixel position whenever the map moves or the selected feature changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !selectedFeature?.latlng) { setPopupPos(null); return; }
    const update = () => {
      const pt = map.latLngToContainerPoint(selectedFeature.latlng);
      const cw = map.getContainer().clientWidth;
      setPopupPos({ x: pt.x, y: pt.y, cw });
    };
    update();
    map.on('move', update);
    return () => map.off('move', update);
  }, [selectedFeature]);

  useEffect(() => {
    setLoading(true);
    getAllocationsForAnalytics(days)
      .then(r  => { setRows(r);   setLoading(false); })
      .catch(e => { console.warn('analytics:', e.message); setLoading(false); });
  }, [days]);

  useEffect(() => {
    fetch(API_URL, { headers: { KeyID: API_KEY } })
      .then(r => r.json())
      .then(d => {
        const all = d.data?.features || d.features || [];
        setActiveRaw(all.filter(f => f.properties?.source?.sourceName === 'TowAllocation'));
      })
      .catch(() => {});
    getRecentAllocations(1)
      .then(setClearedRaw)
      .catch(() => {});
  }, []);

  // ── Derived ─────────────────────────────────────────────────────────────────
  const features = useMemo(() => rows.map(r => ({
    ...r,
    props:  r.data?.properties || {},
    coords: r.data?.geometry?.coordinates,
  })), [rows]);

  const hourCounts = Array(24).fill(0);
  const dowCounts  = Array(7).fill(0);
  features.forEach(f => {
    const d = new Date(f.first_seen || f.event_created_at);
    if (!isNaN(d)) { hourCounts[d.getHours()]++; dowCounts[d.getDay()]++; }
  });

  const peakHourIdx = hourCounts.indexOf(Math.max(...hourCounts));
  const peakHour    = hourCounts[peakHourIdx] > 0
    ? `${String(peakHourIdx).padStart(2, '0')}:00–${String(peakHourIdx + 1).padStart(2, '0')}:00`
    : '—';

  const topSuburbs  = tally(features, f => f.suburb);
  const topRoads    = tally(features, f => f.road_name);
  const incTypes    = tally(features, f => f.props.eventSubType);
  const impTypes    = tally(features, f => f.props.impact?.impactType);

  const durations = features
    .filter(f => f.first_seen && f.last_seen)
    .map(f => (new Date(f.last_seen) - new Date(f.first_seen)) / 60000)
    .filter(m => m > 0 && m < 60 * 24);
  const avgDuration = durations.length
    ? durations.reduce((a, b) => a + b, 0) / durations.length
    : null;

  const avgPerDay   = features.length ? (features.length / days).toFixed(1) : '0';
  const topSuburb   = topSuburbs[0]?.[0] || '—';
  const mapPoints = useMemo(
    () => features.filter(f => f.coords).map(f => [f.coords[1], f.coords[0]]),
    [features],
  );

  const activeEventIds = useMemo(
    () => new Set(activeRaw.map(f => String(f.properties?.eventId))),
    [activeRaw],
  );
  const activeMapPoints = useMemo(
    () => activeRaw
      .filter(f => f.geometry?.coordinates)
      .map(f => ({ pos: [f.geometry.coordinates[1], f.geometry.coordinates[0]], feature: f })),
    [activeRaw],
  );
  const clearedMapPoints = useMemo(
    () => clearedRaw
      .filter(f => f.geometry?.coordinates && !activeEventIds.has(String(f.properties?.eventId)))
      .map(f => ({ pos: [f.geometry.coordinates[1], f.geometry.coordinates[0]], feature: f })),
    [clearedRaw, activeEventIds],
  );

  return (
    <>
    <div style={{ padding: 16, flex: 1, overflowY: 'auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, flexWrap: 'wrap', gap: 8 }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: TXT, letterSpacing: '0.06em' }}>📊 Tow Analytics</div>
          <div style={{ fontSize: 9, color: MUT, marginTop: 2 }}>
            {loading ? 'Loading…' : `${features.length} allocation${features.length !== 1 ? 's' : ''} · last ${days} day${days !== 1 ? 's' : ''}`}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {PERIODS.map(p => (
            <button key={p.days} onClick={() => setDays(p.days)}
              style={{ fontSize: 8, fontWeight: 700, padding: '3px 9px', borderRadius: 2, cursor: 'pointer', fontFamily: "'IBM Plex Mono',monospace", letterSpacing: '0.06em', border: `1px solid ${p.days === days ? ACC + '88' : '#2a2a2a'}`, color: p.days === days ? ACC : MUT, background: p.days === days ? ACC + '11' : '#0d0d0d' }}>
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
        <KpiCard label="Total Jobs"    value={features.length}       color={TXT}    />
        <KpiCard label="Avg / Day"     value={avgPerDay}             color={ACC}    />
        <KpiCard label="Peak Hour"     value={peakHour}              color={ORANGE} sub={hourCounts[peakHourIdx] > 0 ? `${hourCounts[peakHourIdx]} jobs` : undefined} />
        <KpiCard label="Top Suburb"    value={topSuburb}             color={GRN}    sub={topSuburbs[0] ? `${topSuburbs[0][1]} jobs` : undefined} />
        <KpiCard label="Avg Duration"  value={fmtDuration(avgDuration)} color={MUT} sub={durations.length ? `from ${durations.length} jobs` : 'insufficient data'} />
      </div>

      {/* Map + side stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 12, marginBottom: 14 }}>

        {/* Heat map */}
        <div style={{ background: SURF, border: '1px solid ' + BRD, borderRadius: 2, overflow: 'hidden', minHeight: 400 }}>
          <div style={{ padding: '8px 12px', borderBottom: '1px solid ' + BRD, fontSize: 8, color: MUT, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700 }}>
            Incident Map · {mapPoints.length} historical · {activeMapPoints.length} active · {clearedMapPoints.length} cleared
          </div>
          <div style={{ height: 360, position: 'relative' }} onClick={() => setSelectedFeature(null)}>
            {loading
              ? <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', fontSize: 9, color: MUT }}>Loading…</div>
              : (mapPoints.length === 0 && activeMapPoints.length === 0 && clearedMapPoints.length === 0)
                ? <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', fontSize: 9, color: MUT }}>No coordinate data yet</div>
                : <HeatMap
                    hotspots={mapPoints}
                    activePoints={activeMapPoints}
                    clearedPoints={clearedMapPoints}
                    showHotspots={showHotspots}
                    showActive={showActive}
                    showCleared={showCleared}
                    onFeatureClick={onFeatureClick}
                    onMapReady={onMapReady}
                  />
            }
            {/* Map legend */}
            {!loading && (
              <div style={{
                position: 'absolute', bottom: 10, left: 10, zIndex: 1000,
                background: 'rgba(10,10,10,0.88)', border: '1px solid #2a2a2a', borderRadius: 3,
                padding: '7px 10px', display: 'flex', flexDirection: 'column', gap: 5,
                fontFamily: "'IBM Plex Mono',monospace", pointerEvents: 'auto',
              }}>
                {[
                  { color: ORANGE, label: 'Hotspots',     count: mapPoints.length,        show: showHotspots, toggle: setShowHotspots },
                  { color: GRN,    label: 'Active Now',    count: activeMapPoints.length,  show: showActive,   toggle: setShowActive   },
                  { color: '#777', label: 'Cleared (1hr)', count: clearedMapPoints.length, show: showCleared,  toggle: setShowCleared  },
                ].map(({ color, label, count, show, toggle }) => (
                  <button key={label} onClick={e => { e.stopPropagation(); toggle(v => !v); }}
                    style={{ display: 'flex', alignItems: 'center', gap: 7, background: 'none', border: 'none', cursor: 'pointer', padding: 0, opacity: show ? 1 : 0.35, transition: 'opacity 0.15s' }}>
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: color, flexShrink: 0, boxShadow: show ? `0 0 6px ${color}88` : 'none' }} />
                    <span style={{ fontSize: 8, color: MUT, letterSpacing: '0.07em', whiteSpace: 'nowrap' }}>{label} ({count})</span>
                  </button>
                ))}
              </div>
            )}
            {/* Inline popup — anchored to clicked marker, no screen dim */}
            {selectedFeature && popupPos && (
              <div
                onClick={e => e.stopPropagation()}
                style={{
                  position: 'absolute', zIndex: 2000,
                  width: 280, maxHeight: 300, overflowY: 'auto',
                  background: '#0d0d0d', border: '1px solid #3a3a3a', borderRadius: 3,
                  fontFamily: "'IBM Plex Mono',monospace",
                  ...(popupPos.x + 295 <= popupPos.cw
                    ? { left: popupPos.x + 8 }
                    : { right: popupPos.cw - popupPos.x + 8 }),
                  ...(popupPos.y <= 180
                    ? { top:    popupPos.y + 8 }
                    : { bottom: 360 - popupPos.y + 8 }),
                }}
              >
                <button
                  onClick={() => setSelectedFeature(null)}
                  style={{ position: 'absolute', top: 5, right: 5, zIndex: 1, background: 'rgba(10,10,10,0.9)', border: '1px solid #333', color: MUT, cursor: 'pointer', fontSize: 9, lineHeight: 1, padding: '2px 5px', borderRadius: 2, fontFamily: "'IBM Plex Mono',monospace" }}
                >✕</button>
                <AllocationCard feature={selectedFeature.feature} fromLog={selectedFeature.fromLog} />
              </div>
            )}
          </div>
        </div>

        {/* Side stats */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ background: SURF, border: '1px solid ' + BRD, borderRadius: 2, padding: '10px 12px', flex: 1 }}>
            <div style={{ fontSize: 8, color: MUT, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 10 }}>Incident Type</div>
            <BarList data={incTypes} color={ORANGE} maxBars={6} labelWidth={130} />
          </div>
          <div style={{ background: SURF, border: '1px solid ' + BRD, borderRadius: 2, padding: '10px 12px', flex: 1 }}>
            <div style={{ fontSize: 8, color: MUT, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 10 }}>Impact Type</div>
            <BarList data={impTypes} color='#5a7a9a' maxBars={5} labelWidth={130} />
          </div>
        </div>
      </div>

      {/* Peak hours + day of week */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
        <div style={{ background: SURF, border: '1px solid ' + BRD, borderRadius: 2, padding: '10px 12px' }}>
          <div style={{ fontSize: 8, color: MUT, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 10 }}>Jobs by Hour of Day</div>
          <HourChart counts={hourCounts} />
        </div>
        <div style={{ background: SURF, border: '1px solid ' + BRD, borderRadius: 2, padding: '10px 12px' }}>
          <div style={{ fontSize: 8, color: MUT, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 10 }}>Jobs by Day of Week</div>
          <DowChart counts={dowCounts} />
        </div>
      </div>

      {/* Top suburbs + top roads */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <div style={{ background: SURF, border: '1px solid ' + BRD, borderRadius: 2, padding: '10px 12px' }}>
          <div style={{ fontSize: 8, color: MUT, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 10 }}>Hot Suburbs</div>
          <BarList data={topSuburbs} color={GRN} maxBars={10} labelWidth={110} />
        </div>
        <div style={{ background: SURF, border: '1px solid ' + BRD, borderRadius: 2, padding: '10px 12px' }}>
          <div style={{ fontSize: 8, color: MUT, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 10 }}>Hot Roads</div>
          <BarList data={topRoads} color={ORANGE} maxBars={10} labelWidth={110} />
        </div>
      </div>

    </div>
    </>
  );
}
